#define ADMIN_INTERFACE "Welcome Admin!\n1.Add User\n2.Modify\n3.Delete\n4.Search\nEnter Your Choice: "
#define ACC_TYPE_PROMPT "Type of new account\n0.Regular Account\n1.Joint Account\nChoice: "
#define NAME_PROMPT "Create your username : "
#define AGE_PROMPT "Enter your age: "
#define SEX_PROMPT "Enter Sex (male or female): "
#define PASS_PROMPT "Set Password : "

#define SEARCH_INTERFACE "Enter Username to seach for details: "
#define DELETE_INTERFACE "Enter Account Number to delete: "
#define MODIFY_INTERFACE "Enter Account Number to Modify: "
#define MODIFY_OPTIONS "Which field do you want to modify....?\n1.Username\n2.Age\n3.Sex\nEnter your choice: "
#define PROMPT_MODIFICATION "Enter New Value: "

#define USER_INTERFACE "Greetings Banker !!\n1.Deposit\n2.Withdraw\n3.Balance Enquiry\n4.Password Change\n5.View Self Details\n6.Exit\n\nWhat do you want to do today? "

#define SUCCESS_USERADDED "USER ADDED SUCCESSFULLY\n"